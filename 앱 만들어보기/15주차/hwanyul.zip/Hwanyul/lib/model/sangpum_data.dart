
class SangpumData {
  final String id;
  final String name;
  final String link;
  final double price;
  final String currency;
  final DateTime addedDate;

  SangpumData({
    required this.id,
    required this.name,
    required this.link,
    required this.price,
    required this.currency,
    required this.addedDate,
  });

  factory SangpumData.fromJson(Map<String, dynamic> json) {
    return SangpumData(
      id: json['id'],
      name: json['name'],
      link: json['link'],
      price: json['price'].toDouble(),
      currency: json['currency'],
      addedDate: DateTime.parse(json['addedDate']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'link': link,
      'price': price,
      'currency': currency,
      'addedDate': addedDate.toIso8601String(),
    };
  }
}