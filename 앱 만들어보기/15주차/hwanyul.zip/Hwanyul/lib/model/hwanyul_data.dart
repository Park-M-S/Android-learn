
class HwanyulData {
  final String currencyCode;
  final String currencyName;
  final double basicRate;
  final double buyingRate;
  final double sellingRate;

  HwanyulData({
    required this.currencyCode,
    required this.currencyName,
    required this.basicRate,
    required this.buyingRate,
    required this.sellingRate,
  });

  factory HwanyulData.fromJson(Map<String, dynamic> json) {
    return HwanyulData(
      currencyCode: json['cur_unit'] ?? '',
      currencyName: json['cur_nm'] ?? '',
      basicRate: double.tryParse(json['deal_bas_r']?.toString().replaceAll(',', '') ?? '0') ?? 0.0,
      buyingRate: double.tryParse(json['bkpr']?.toString().replaceAll(',', '') ?? '0') ?? 0.0,
      sellingRate: double.tryParse(json['yy_efee_r']?.toString().replaceAll(',', '') ?? '0') ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cur_unit': currencyCode,
      'cur_nm': currencyName,
      'deal_bas_r': basicRate.toString(),
      'bkpr': buyingRate.toString(),
      'yy_efee_r': sellingRate.toString(),
    };
  }
}