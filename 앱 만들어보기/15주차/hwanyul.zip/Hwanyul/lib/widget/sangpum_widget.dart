import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../model/sangpum_data.dart';
import '../util/hwanyul_gyesan.dart';
import '../model/hwanyul_data.dart';

class SangpumWidget {
  // 링크 열기 함수 (강화된 버전)
  static Future<void> _openLink(BuildContext context, String url) async {
    try {
      // URL 정리 및 검증
      String finalUrl = url.trim();

      // 프로토콜이 없으면 https:// 추가
      if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
        finalUrl = 'https://$finalUrl';
      }

      print('시도할 URL: $finalUrl'); // 디버깅용

      // URL 파싱 및 검증
      final Uri uri = Uri.parse(finalUrl);

      // URL 유효성 검사
      if (uri.host.isEmpty) {
        _showUrlDialog(context, finalUrl, '잘못된 URL 형식입니다');
        return;
      }

      // 여러 방법으로 링크 열기 시도
      bool success = false;

      // 방법 1: externalApplication 모드
      try {
        if (await canLaunchUrl(uri)) {
          success = await launchUrl(
            uri,
            mode: LaunchMode.externalApplication,
          );
        }
      } catch (e) {
        print('externalApplication 모드 실패: $e');
      }

      // 방법 2: platformDefault 모드
      if (!success) {
        try {
          success = await launchUrl(
            uri,
            mode: LaunchMode.platformDefault,
          );
        } catch (e) {
          print('platformDefault 모드 실패: $e');
        }
      }

      // 방법 3: inAppWebView 모드
      if (!success) {
        try {
          success = await launchUrl(
            uri,
            mode: LaunchMode.inAppWebView,
          );
        } catch (e) {
          print('inAppWebView 모드 실패: $e');
        }
      }

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('링크를 열었습니다')),
        );
      } else {
        // 모든 방법이 실패한 경우 URL 표시
        _showUrlDialog(context, finalUrl, '링크를 자동으로 열 수 없습니다');
      }

    } catch (e) {
      print('링크 열기 오류: $e'); // 디버깅용
      _showUrlDialog(context, url, '오류가 발생했습니다: ${e.toString()}');
    }
  }

  // URL 표시 다이얼로그
  static void _showUrlDialog(BuildContext context, String url, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.link, color: Colors.blue),
            SizedBox(width: 8),
            Text('상품 링크'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: SelectableText(
                url,
                style: TextStyle(
                  fontFamily: 'monospace',
                  color: Colors.blue.shade700,
                ),
              ),
            ),
            SizedBox(height: 8),
            Text(
              '위 URL을 복사해서 브라우저에 직접 입력하세요.',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('확인'),
          ),
          ElevatedButton(
            onPressed: () {
              // 클립보드 복사 (추후 구현 가능)
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('URL을 길게 눌러 복사할 수 있습니다')),
              );
            },
            child: Text('닫기'),
          ),
        ],
      ),
    );
  }

  // 상품 추가 다이얼로그
  static void showAddSangpumDialog(
      BuildContext context,
      List<SangpumData> sangpumList,
      VoidCallback onSangpumAdded,
      ) {
    final nameController = TextEditingController();
    final linkController = TextEditingController();
    final priceController = TextEditingController();
    String selectedCurrency = 'USD';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('상품 등록'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: '상품명',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: linkController,
                  decoration: const InputDecoration(
                    labelText: '상품 링크',
                    border: OutlineInputBorder(),
                    hintText: 'amazon.com/product 또는 https://쇼핑몰.com',
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: priceController,
                        keyboardType: TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          labelText: '가격',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    DropdownButton<String>(
                      value: selectedCurrency,
                      items: HwanyulGyesan.getSupportedCurrencies()
                          .map((currency) => DropdownMenuItem(
                        value: currency,
                        child: Text(currency),
                      ))
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() {
                            selectedCurrency = value;
                          });
                        }
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('취소'),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty &&
                    linkController.text.isNotEmpty &&
                    priceController.text.isNotEmpty) {
                  final sangpum = SangpumData(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    name: nameController.text,
                    link: linkController.text,
                    price: double.parse(priceController.text),
                    currency: selectedCurrency,
                    addedDate: DateTime.now(),
                  );

                  sangpumList.add(sangpum);
                  onSangpumAdded();
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('상품이 등록되었습니다.')),
                  );
                }
              },
              child: const Text('등록'),
            ),
          ],
        ),
      ),
    );
  }

  // 상품 목록 모달
  static void showSangpumDrawer(
      BuildContext context,
      List<SangpumData> sangpumList,
      Map<String, HwanyulData> hwanyulRates,
      VoidCallback onSangpumAdded,
      VoidCallback onSangpumDeleted,
      ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        expand: false,
        builder: (context, scrollController) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '등록된 상품',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    ElevatedButton.icon(
                      onPressed: () => showAddSangpumDialog(context, sangpumList, onSangpumAdded),
                      icon: const Icon(Icons.add),
                      label: const Text('상품 추가'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: sangpumList.isEmpty
                    ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.shopping_bag_outlined, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('등록된 상품이 없습니다.', style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                )
                    : ListView.builder(
                  controller: scrollController,
                  itemCount: sangpumList.length,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemBuilder: (context, index) {
                    final sangpum = sangpumList[index];
                    final krwPrice = HwanyulGyesan.convertPriceToKRW(
                      sangpum.price,
                      sangpum.currency,
                      hwanyulRates,
                    );

                    return Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: ListTile(
                        leading: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.shopping_bag, color: Colors.grey),
                        ),
                        title: Text(sangpum.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${HwanyulGyesan.formatCurrency(sangpum.price)} ${sangpum.currency}'),
                            Text('≈ ${HwanyulGyesan.formatCurrency(krwPrice)} KRW',
                                style: const TextStyle(color: Colors.blue)),
                          ],
                        ),
                        trailing: PopupMenuButton(
                          itemBuilder: (context) => [
                            PopupMenuItem(
                              value: 'link',
                              child: const Row(
                                children: [
                                  Icon(Icons.open_in_new, color: Colors.blue),
                                  SizedBox(width: 8),
                                  Text('링크 열기'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: 'delete',
                              child: const Row(
                                children: [
                                  Icon(Icons.delete, color: Colors.red),
                                  SizedBox(width: 8),
                                  Text('삭제', style: TextStyle(color: Colors.red)),
                                ],
                              ),
                            ),
                          ],
                          onSelected: (value) {
                            if (value == 'link') {
                              _openLink(context, sangpum.link);
                            } else if (value == 'delete') {
                              sangpumList.removeAt(index);
                              onSangpumDeleted();
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('상품이 삭제되었습니다.')),
                              );
                            }
                          },
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}