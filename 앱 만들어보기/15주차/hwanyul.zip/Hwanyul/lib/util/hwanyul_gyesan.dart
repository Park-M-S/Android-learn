import 'package:intl/intl.dart';
import '../model/hwanyul_data.dart';

class HwanyulGyesan {
  static final NumberFormat _currencyFormatter = NumberFormat('#,##0.00');

  // 금액을 지정된 통화로 변환
  static double convertCurrency(
      double amount,
      String fromCurrency,
      String toCurrency,
      Map<String, HwanyulData> hwanyulRates,
      ) {
    if (amount == 0) return 0;
    if (fromCurrency == toCurrency) return amount;

    double rate = _getHwanyulRate(fromCurrency, toCurrency, hwanyulRates);
    return amount * rate;
  }

  // 환율 정보 가져오기
  static double _getHwanyulRate(
      String fromCurrency,
      String toCurrency,
      Map<String, HwanyulData> hwanyulRates,
      ) {
    if (fromCurrency == toCurrency) return 1.0;

    // KRW를 기준으로 환율 계산
    if (fromCurrency == 'KRW') {
      final toRate = hwanyulRates[toCurrency]?.basicRate ?? 1;

      if (toCurrency == 'JPY') {
        return 100 / toRate; // JPY는 100엔 기준
      } else {
        return 1 / toRate;
      }
    } else if (toCurrency == 'KRW') {
      final fromRate = hwanyulRates[fromCurrency]?.basicRate ?? 1;

      if (fromCurrency == 'JPY') {
        return fromRate / 100; // JPY는 100엔 기준
      } else {
        return fromRate;
      }
    } else {
      // 둘 다 외화인 경우
      final fromRate = hwanyulRates[fromCurrency]?.basicRate ?? 1;
      final toRate = hwanyulRates[toCurrency]?.basicRate ?? 1;

      if (toCurrency == 'JPY' && fromCurrency != 'JPY') {
        return (toRate / 100) / fromRate;
      } else if (toCurrency != 'JPY' && fromCurrency == 'JPY') {
        return (toRate / fromRate) * 100;
      } else if (toCurrency == 'JPY' && fromCurrency == 'JPY') {
        return toRate / fromRate;
      } else {
        return toRate / fromRate;
      }
    }
  }

  // 가격을 KRW로 변환
  static double convertPriceToKRW(
      double price,
      String currency,
      Map<String, HwanyulData> hwanyulRates,
      ) {
    if (currency == 'KRW') return price;

    final rate = hwanyulRates[currency]?.basicRate ?? 1;

    if (currency == 'JPY') {
      return price * (rate / 100);
    } else {
      return price * rate;
    }
  }

  // 환율 정보 문자열 생성
  static String getHwanyulInfo(
      String fromCurrency,
      String toCurrency,
      Map<String, HwanyulData> hwanyulRates,
      ) {
    if (fromCurrency == toCurrency) {
      return '1 $fromCurrency = 1 $toCurrency';
    }

    final rate = _getHwanyulRate(fromCurrency, toCurrency, hwanyulRates);
    return '1 $fromCurrency = ${rate.toStringAsFixed(4)} $toCurrency';
  }

  // 역방향 환율 정보 문자열 생성
  static String getReverseHwanyulInfo(
      String fromCurrency,
      String toCurrency,
      Map<String, HwanyulData> hwanyulRates,
      ) {
    if (fromCurrency == toCurrency) {
      return '1 $toCurrency = 1 $fromCurrency';
    }

    final rate = _getHwanyulRate(toCurrency, fromCurrency, hwanyulRates);
    return '1 $toCurrency = ${rate.toStringAsFixed(4)} $fromCurrency';
  }

  // 통화 형식 포맷팅
  static String formatCurrency(double amount) {
    return _currencyFormatter.format(amount);
  }

  // 지원하는 통화 목록
  static List<String> getSupportedCurrencies() {
    return ['KRW', 'USD', 'EUR', 'JPY', 'GBP', 'CNY'];
  }
}