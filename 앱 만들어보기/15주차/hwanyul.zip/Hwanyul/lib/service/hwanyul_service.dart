// service/hwanyul_service.dart
import '../model/hwanyul_data.dart';

class HwanyulService {
  // 기본 환율 데이터 (2025년 6월 20일 기준)
  static Map<String, HwanyulData> getDefaultHwanyulRates() {
    return {
      'USD': HwanyulData(
        currencyCode: 'USD',
        currencyName: '미국 달러',
        basicRate: 1372.71, // 2025.06.20 실제 환율 반영
        buyingRate: 1358.50,
        sellingRate: 1386.92,
      ),
      'EUR': HwanyulData(
        currencyCode: 'EUR',
        currencyName: '유럽연합 유로',
        basicRate: 1480.35,
        buyingRate: 1465.15,
        sellingRate: 1495.55,
      ),
      'JPY': HwanyulData(
        currencyCode: 'JPY',
        currencyName: '일본 엔',
        basicRate: 876.42, // 100엔 기준
        buyingRate: 867.85,
        sellingRate: 884.99,
      ),
      'GBP': HwanyulData(
        currencyCode: 'GBP',
        currencyName: '영국 파운드',
        basicRate: 1745.28,
        buyingRate: 1728.43,
        sellingRate: 1762.13,
      ),
      'CNY': HwanyulData(
        currencyCode: 'CNY',
        currencyName: '중국 위안',
        basicRate: 188.95,
        buyingRate: 187.07,
        sellingRate: 190.83,
      ),
    };
  }

  // 실시간 환율 업데이트 (추후 구현)
  static Future<Map<String, HwanyulData>> updateRealTimeRates() async {
    // TODO: 실제 API 연동 구현 예정
    await Future.delayed(Duration(seconds: 2)); // 로딩 시뮬레이션
    return getDefaultHwanyulRates();
  }
}