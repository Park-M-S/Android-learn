import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'model/hwanyul_data.dart';
import 'model/sangpum_data.dart';
import 'service/hwanyul_service.dart';
import 'util/hwanyul_gyesan.dart';
import 'widget/sangpum_widget.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '실시간 환율 계산기',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MainHwanyulScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainHwanyulScreen extends StatefulWidget {
  @override
  _MainHwanyulScreenState createState() => _MainHwanyulScreenState();
}

class _MainHwanyulScreenState extends State<MainHwanyulScreen> {
  final TextEditingController _amountController = TextEditingController(text: '1');
  String _fromCurrency = 'USD';
  String _toCurrency = 'KRW';
  double _convertedAmount = 0;
  bool _isLoading = false;
  String _lastUpdateTime = '2025-06-20 15:30';

  Map<String, HwanyulData> _hwanyulRates = {};
  List<SangpumData> _sangpumList = [];

  @override
  void initState() {
    super.initState();
    _loadDefaultHwanyulRates();
    _updateConversion();
  }

  void _loadDefaultHwanyulRates() {
    setState(() {
      _hwanyulRates = HwanyulService.getDefaultHwanyulRates();
      _hwanyulRates['KRW'] = HwanyulData(
        currencyCode: 'KRW',
        currencyName: '한국 원',
        basicRate: 1,
        buyingRate: 1,
        sellingRate: 1,
      );
    });
  }

  Future<void> _loadRealTimeHwanyulRates() async {
    setState(() => _isLoading = true);

    try {
      final rates = await HwanyulService.updateRealTimeRates();
      setState(() {
        _hwanyulRates = rates;
        _hwanyulRates['KRW'] = HwanyulData(
          currencyCode: 'KRW',
          currencyName: '한국 원',
          basicRate: 1,
          buyingRate: 1,
          sellingRate: 1,
        );
        // 임의의 업데이트 시간으로 설정
        _lastUpdateTime = '2025-06-20 ${DateTime.now().hour.toString().padLeft(2, '0')}:${DateTime.now().minute.toString().padLeft(2, '0')}';
      });
      _updateConversion();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('추후 구현할 기능입니다: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _updateConversion() {
    final amount = double.tryParse(_amountController.text) ?? 0;
    setState(() {
      _convertedAmount = HwanyulGyesan.convertCurrency(
        amount,
        _fromCurrency,
        _toCurrency,
        _hwanyulRates,
      );
    });
  }

  void _swapCurrencies() {
    setState(() {
      final temp = _fromCurrency;
      _fromCurrency = _toCurrency;
      _toCurrency = temp;
      _updateConversion();
    });
  }

  String _getHwanyulInfo() {
    return HwanyulGyesan.getHwanyulInfo(_fromCurrency, _toCurrency, _hwanyulRates);
  }

  String _getReverseHwanyulInfo() {
    return HwanyulGyesan.getReverseHwanyulInfo(_fromCurrency, _toCurrency, _hwanyulRates);
  }

  void _showSangpumDrawer() {
    SangpumWidget.showSangpumDrawer(
      context,
      _sangpumList,
      _hwanyulRates,
          () => setState(() {}),
          () => setState(() {}),
    );
  }

  Widget _buildCurrencyDropdown(String value, Function(String?) onChanged) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(4),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButton<String>(
        value: value,
        icon: const Icon(Icons.arrow_drop_down),
        underline: Container(),
        items: HwanyulGyesan.getSupportedCurrencies().map<DropdownMenuItem<String>>((String currency) {
          return DropdownMenuItem<String>(
            value: currency,
            child: Text(currency),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          '실시간 환율 계산기',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: _showSangpumDrawer,
          tooltip: '상품 관리',
        ),
        actions: [
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 환율 계산 카드
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _amountController,
                            keyboardType: TextInputType.numberWithOptions(decimal: true),
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                            ],
                            decoration: InputDecoration(
                              labelText: '금액',
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (_) => _updateConversion(),
                          ),
                        ),
                        const SizedBox(width: 16),
                        _buildCurrencyDropdown(_fromCurrency, (value) {
                          if (value != null) {
                            setState(() {
                              _fromCurrency = value;
                              _updateConversion();
                            });
                          }
                        }),
                      ],
                    ),
                    const SizedBox(height: 16),
                    IconButton(
                      icon: const Icon(Icons.swap_vert),
                      onPressed: _swapCurrencies,
                      tooltip: '통화 교환',
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.blue.shade100,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              HwanyulGyesan.formatCurrency(_convertedAmount),
                              style: const TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        _buildCurrencyDropdown(_toCurrency, (value) {
                          if (value != null) {
                            setState(() {
                              _toCurrency = value;
                              _updateConversion();
                            });
                          }
                        }),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // 환율 정보 카드
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('환율 정보', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        Icon(
                          Icons.circle,
                          size: 12,
                          color: Colors.green,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _getHwanyulInfo(),
                      style: const TextStyle(fontSize: 16),
                    ),
                    Text(
                      _getReverseHwanyulInfo(),
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 8),
                    if (_fromCurrency != 'KRW' && _hwanyulRates[_fromCurrency] != null) Text(
                      '통화 이름: ${_hwanyulRates[_fromCurrency]!.currencyName}',
                      style: const TextStyle(fontSize: 14, color: Colors.blue),
                    ),
                    if (_toCurrency != 'KRW' && _hwanyulRates[_toCurrency] != null) Text(
                      '통화 이름: ${_hwanyulRates[_toCurrency]!.currencyName}',
                      style: const TextStyle(fontSize: 14, color: Colors.blue),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '마지막 업데이트: $_lastUpdateTime',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // 주요 통화 환율 카드 (스크롤 가능한 고정 높이)
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('주요 통화 환율', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.5, // 화면 높이의 50%
                      child: _hwanyulRates.isEmpty
                          ? const Center(
                        child: CircularProgressIndicator(),
                      )
                          : ListView.builder(
                        itemCount: _hwanyulRates.length - 1,
                        itemBuilder: (context, index) {
                          final currencies = _hwanyulRates.keys.where((key) => key != 'KRW').toList();
                          if (index >= currencies.length) return const SizedBox.shrink();

                          final currencyCode = currencies[index];
                          final currency = _hwanyulRates[currencyCode]!;

                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: Colors.blue.shade100,
                                child: Text(
                                  currencyCode,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              title: Text(
                                '${currency.currencyName} ($currencyCode)',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    '매매기준율: ${HwanyulGyesan.formatCurrency(currency.basicRate)} 원${currencyCode == 'JPY' ? ' (100엔 기준)' : ''}',
                                    style: const TextStyle(fontSize: 14),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: [
                                        Text(
                                          '살 때: ${HwanyulGyesan.formatCurrency(currency.buyingRate)} 원',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.red.shade600,
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Text(
                                          '팔 때: ${HwanyulGyesan.formatCurrency(currency.sellingRate)} 원',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.blue.shade600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.trending_up,
                                    color: Colors.grey.shade600,
                                    size: 16,
                                  ),
                                  Text(
                                    'DEMO',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey.shade600,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // 새로고침 버튼
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : () async {
                      await _loadRealTimeHwanyulRates();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('추후 구현할 기능입니다'),
                          backgroundColor: Colors.orange,
                        ),
                      );
                    },
                    icon: _isLoading
                        ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                        : const Icon(Icons.refresh),
                    label: Text(_isLoading ? '업데이트 중...' : '실시간 환율 새로고침'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20), // 하단 여백 추가
          ],
        ),
      ),
    );
  }
}